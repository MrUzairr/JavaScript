const character =[
    {   
        name : 'Ahmad',
        height : 145,
        weight : 77,
        eye_color : 'black',
        gender: 'male',
    },
    {
        name : 'Amna',
        height : 134,
        weight : 65,
        eye_color : 'brown',
        gender: 'female',
    },
    {
        name : 'Bilal',
        height : 156,
        weight : 72,
        eye_color : 'blue',
        gender: 'male',
    },

];
const names = character.map(ch => ch.name)
// console.log(names)
const getHeight = character.map(ch => {
    return   {name:ch.name,height:ch.height}        
}        
)
// console.log(getHeight)

const totalHeight = character.reduce((previousHeight,characters) => {
    return  previousHeight + characters.height;
    },0
)
// console.log(totalHeight)
const greaterMass = character.filter(ch => ch.weight>70)
// console.log(greaterMass)
const getGender = character.filter(ch =>ch.gender=='male')
//console.log(getGender)
const sortByGender = character.sort((ch1,ch2) =>{
    if(ch1.gender>ch2.gender){
        return -1;
    }
    if(ch1.gender<ch2.gender){
        return 1;
    }
    return 0;
}
)
//console.log(sortByGender)
const sortByName = character.sort((ch1,ch2) =>{
    if(ch1.name>ch2.name){
        return -1;
    }
    if(ch1.name<ch2.name){
        return 1;
    }
    return 0;
    }
    )
//console.log(sortByName)
// console.log(character.every(ch=>ch.weight>60}))
//console.log(character.every(ch=>ch.eye_color=='blue'))
const atleastOneMale = character.some(ch => ch.gender==='male')
//console.log(atleastOneMale)
const tallerThan150 = character.some(ch => ch.height>150)
//console.log(tallerThan150)
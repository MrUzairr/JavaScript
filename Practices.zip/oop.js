class Product{
    constructor(itemName){
        this.itemName = itemName;
    }
    getItemName(){
        return this.itemName+' is a Product';
    }
}
class Furniture extends Product{
    constructor(itemName){
        super(itemName);
    }
    getItemName(){
        return this.itemName + " is a Furniture";
    }
}

let pencil = new Product('pencil');

let chair = new Furniture('chair');
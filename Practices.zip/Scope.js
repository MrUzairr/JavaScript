

function first(){
   var x= 1;
//    console.log(x)  
    function second(){
        var x = 2;
       // console.log(x)
        function Third(){
            var x = 3;
            console.log(x)
        }
        Third();
    } 
    second();   
}
first();
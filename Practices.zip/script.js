let outputBtn = document.querySelector('button');
outputBtn.addEventListener('click',showMsg);
function showMsg(){
    let txt = prompt("Enter the Student Name:");
    outputBtn.textContent = 'Roll No 1:'+ txt;
}

var x=14,y=4;
x=x%y;
x
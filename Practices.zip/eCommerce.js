
//Object
const item={
    itemName :'clothes',
    itemPrice : 3000,
    itemDiscount : 30,
    itemCode : '1001'
};

//Factory function
function productItem(itemName,itemPrice,itemDiscount,itemCode){
    return {
        itemName :itemName,
        itemPrice : itemPrice,
        itemDiscount : itemDiscount,
        itemCode : itemCode
    } 
}

const clothes = productItem('coat',4000,150,'F2F')

//Constructor function
function ProductItem(itemName,itemPrice,itemDiscount,itemCode){
    this.itemName =itemName,
    this.itemPrice = itemPrice,
    this.itemDiscount = itemDiscount,
    this.itemCode = itemCode
    this.getDiscount = function(){
        let disc = itemPrice * (itemDiscount/100);
        return disc;
    }

}

const car = new ProductItem('Car',4000000,30,'AFY5018');
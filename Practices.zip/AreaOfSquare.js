// function getArea(side){
//     return side*side;
// }
// let area = getArea(3);
// console.log(area);

// let square={
//     side : 5,
//     get Area(){
//        return this.side**2;
//     }
// }
// square.side = 10;
// console.log(square.Area);

// function stringConcat(separator,...strings){
//  for(let array of strings){
//         array = separator + strings;
//         console.log(array);
//     }
// }
// function stringConcat(separator,...strings){
//     let returnVal = ''
//     strings.forEach((string,i)=>{
//         if(i == strings.length-1){
//             returnVal += string;
//         }  
//         else{
//             returnVal += string + separator;
//         }
//        })
//        return returnVal;
//    }
// let array = stringConcat('_','air','water','food');
// console.log(array);
// let arr = [1,2,3,4,5,6,7,8]
// let first = arr[0];
// let second = arr[1]
// let third = arr[2];
// let other = arr.slice(3);
// let [first,second,third,...other] = [1,2,3,4,5,6,7,8]



//3rd MatchHouse

// let input;
// let flag = true;
// function getMatchHouse(){
//     input = prompt('matchHouse:');
//         if(input == 0){
//             console.log(0)
//         }
//         else if(input == 1){
//             console.log(6)
//         }
//         else{
//             let x = 6 + (input*5-5);
//             console.log(x);
//         }
    
// }
// function menu(){
//     console.log('1 input');
//     console.log('2 exit');
//     let i = prompt('Enter input');
//     return i;
// }
// function takeOutput(){
//     while(flag == true){
//     let i = menu();
//         if(i==1){
//             getMatchHouse();
//         }
//         else if(i==2){
//             break;
//         }
//         else{
//             console.log('Wrong input');
//         }
        
        
//     }
// }
// takeOutput();
// function takeMatchHouse(step){
//     if(step===0){
//         return 0;
//     }
//     else{
//         return (step*6)-(step-1);
//     }
// }
// console.log(takeMatchHouse(1));
// console.log(takeMatchHouse(4));
// console.log(takeMatchHouse(87));
